// User roles:
// - IT Administrator
// - Administrator
// - Organization Risk Management Director
// - Process Owner
// - Risk owner
// - Control owner
// - Control Tester
// - RCM ?
// - Internal Auditor
// - BCP Manager
// - Compliance Director
// - Other (can define specific views and priviliages for users)

export const roles = [
    {
        name: "IT Administrator",
        id: "it_administrator",
    },
    {
        name: "Administrator",
        id: "administrator",
    },
    {
        name: "Organization Risk Management Director",
        id: "orm_director",
    },
    {
        name: "Process Owner",
        id: "process_owner",
    },
    {
        name: "Risk owner",
        id: "risk_owner",
    },
    {
        name: "Control owner",
        id: "control_owner",
    },
    {
        name: "Control Tester",
        id: "control_tester",
    },
    {
        name: "RCM",
        id: "rcm",
    },
    {
        name: "Internal Auditor",
        id: "internal_auditor",
    },
    // {
    //     name: "BCP Manager",
    // },
    // {
    //     name: "Compliance Director",
    // },
];

export const permissions = [
    {
        
    }
]

