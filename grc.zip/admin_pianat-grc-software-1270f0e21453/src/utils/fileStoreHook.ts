import create, { StoreApi, UseBoundStore } from "zustand";
import { CloudFile } from "./fileSystemHook";

export interface FilesState {
    files: CloudFile[];
    addFile: (file: CloudFile) => void;
    removeFile: (file: CloudFile) => void;
    hasFile: (file: CloudFile, files: Array<CloudFile>) => boolean;
    getFiles: () => Array<CloudFile>;

}

const useFilesStore: UseBoundStore<StoreApi<FilesState>> = create<FilesState>((set) => ({
    files: [],
    addFile: (file: CloudFile) => {
        if (!useFilesStore.getState().hasFile(file, useFilesStore.getState().files)) {
            set((state) => ({ files: [...state.files, file] }))
        }
        return;
    },
    removeFile: (file: CloudFile) => {
        set((state) => ({ files: state.files.filter((f) => f.name !== file.name && f.path !== file.path) }))
    },
    hasFile: (file: CloudFile, files: Array<CloudFile>) => {
        const fileNames = files.map((f) => f.name + f.path);
        return fileNames.includes(file.name + file.path);
    },
    getFiles: () => {
        return useFilesStore.getState().files;
    },
}));

export default useFilesStore;
