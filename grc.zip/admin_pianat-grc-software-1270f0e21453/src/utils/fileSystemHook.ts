
export interface CloudNode {
    name: string;
    path: string;
    type: 'file' | 'folder';
}

export interface CloudFolder extends CloudNode {
    name: string;
    path: string;
    children: Array<CloudFile | CloudFolder>;
    type: 'folder';
}

export interface CloudFile extends CloudNode {
    mimeType?: string;
    size?: number;
    lastModified?: number;
    type: 'file';
}



const useFileSystem = () => {
    const mockFileSystem: Array<CloudNode> = [
        {
            name: 'images',
            path: '/',
            type: 'folder',
            children: [
                {
                    name: '2021',
                    type: 'folder',
                    children: [
                        {
                            name: 'document.pdf',
                            path: '/images/2021/document.pdf',
                            type: 'file',
                        }
                    ]
                },
                {
                    name: 'image1.jpg',
                    mimeType: 'image/jpeg',
                    size: 123456,
                    lastModified: 123456789,
                    type: 'file',
                }
            ],
        } as CloudFolder,
    ];

    return {
        files: mockFileSystem
    }
}

export default useFileSystem;