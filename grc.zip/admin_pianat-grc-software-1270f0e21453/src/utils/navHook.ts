import { useRouter } from "next/router";
import useTabsStore, { Tab } from "./tabsHook";

export const useRiskNavigation = () => {
    const router = useRouter();
    const addTab = useTabsStore(state => state.addTab);
    const setActiveTab = useTabsStore(state => state.setActiveTab);
    const removeTab = useTabsStore(state => state.removeTab);
    const switchToCatalog = () => {
        const activeTab = useTabsStore.getState().activeTab;
        if (activeTab?.href === '/risks') return;
        const tab: Tab = {
            id: 'risks catalog',
            name: 'Risks Catalog',
            href: '/risks',
            removable: true,
        };
        if (activeTab)
            removeTab(activeTab);
        addTab(tab);
        setActiveTab(tab);

    }

    const navigateTo = (riskId: string) => {
        const tab = {
            id: riskId,
            name: riskId,
            href: `/risks/${riskId}`,
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }

    const createRisk = () => {
        const tab = {
            id: 'createrisk',
            name: 'Create Risk',
            href: '/risks/create',
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }

    const assessRisk = (riskId: string) => {
        const tab = {
            id: `${riskId}-assessment`,
            name: `${riskId} Assessment`,
            href: `/risks/${riskId}/assessment`,
            removable: true,
        }
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }

    return {
        navigateTo,
        createRisk,
        assessRisk,
        switchToCatalog
    }
}

export const useControlNavigation = () => {
    const router = useRouter();
    const addTab = useTabsStore(state => state.addTab);
    const setActiveTab = useTabsStore(state => state.setActiveTab);

    const navigateTo = (controlId: string, fromRiskid?: string) => {
        const tab = {
            id: controlId,
            name: controlId,
            href: `/controls/${controlId}`,
            removable: true,
            meta: fromRiskid !== undefined ? { 'fromRiskId': fromRiskid } : undefined
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }

    const testControl = (controlId: string) => {
        const tab = {
            id: `${controlId}-testing`,
            name: `${controlId} Testing`,
            href: `/controls/${controlId}/assessment`,
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }


    const createControl = () => {
        const tab: Tab = { href: '/controls/create', name: 'Create Control', id: 'create control', removable: true };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }



    return {
        navigateTo,
        testControl,
        createControl
    }
}

export const useRiskAssessmentNavigation = () => {
    const router = useRouter();
    const addTab = useTabsStore(state => state.addTab);
    const setActiveTab = useTabsStore(state => state.setActiveTab);

    const navigateTo = (riskId: string) => {
        const tab = {
            id: riskId,
            name: `${riskId} assessment`,
            href: `/risks/${riskId}/assessment`,
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }
    return {
        navigateTo,
    }
}

export const useControlAssessmentNavigation = () => {
    const router = useRouter();
    const addTab = useTabsStore(state => state.addTab);
    const setActiveTab = useTabsStore(state => state.setActiveTab);

    const navigateTo = (controlId: string) => {
        const tab = {
            id: controlId,
            name: `${controlId} assessment`,
            href: `/controls/${controlId}/assessment`,
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }
    return {
        navigateTo,
    }
}

export const useFunctionNavigation = () => {
    const router = useRouter();
    const addTab = useTabsStore(state => state.addTab);
    const setActiveTab = useTabsStore(state => state.setActiveTab);

    const navigateTo = (functionId: string) => {
        const tab = {
            id: functionId,
            name: functionId,
            href: `/functions/${functionId}`,
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }


    const createFunction = () => {
        const tab = {
            id: 'createfunction',
            name: 'Create Function',
            href: '/functions/create',
            removable: true,
        };
        addTab(tab);
        setActiveTab(tab);
        router.push(tab.href);
    }

    const removeTab = useTabsStore(state => state.removeTab);

    const switchToCatalog = () => {
        const activeTab = useTabsStore.getState().activeTab;
        if (activeTab?.href === '/functions') return;
        const tab: Tab = {
            id: 'functions',
            name: 'Functions Catalog',
            href: '/functions',
            removable: true,
        };
        if (activeTab)
            removeTab(activeTab);
        addTab(tab);
        setActiveTab(tab);

    }

    return {
        navigateTo,
        createFunction,
        switchToCatalog
    }
}
