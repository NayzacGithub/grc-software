import { BuildingOfficeIcon } from "@heroicons/react/24/solid"

export const OrganizationWelcome: React.FunctionComponent = () => {
    return <header className="py-2 px-8 ">
        <div className="flex gap-4">
            <div className=" h-24 w-24 bg-white rounded-xl border-4 overflow-clip border-gray-200 object-contain">
                <BuildingOfficeIcon className="text-gray-500 " />
            </div>
            <h1 className="text-xl font-bold my-auto text-gray-700">Welcome, User</h1>
        </div>
    </header>
}
