import { DocumentIcon, FolderMinusIcon, FolderPlusIcon, LinkIcon, XCircleIcon } from "@heroicons/react/24/outline";
import { XCircleIcon as XMarkIcon } from "@heroicons/react/24/solid";
import clsx from "clsx";
import { useState } from "react";
import useFilesStore from "../../utils/fileStoreHook";
import useFileSystem, { CloudFile, CloudFolder, CloudNode } from "../../utils/fileSystemHook";

interface FileBrowserProps {
    onClose: () => void;
}

const FilesSelected: React.FunctionComponent = () => {

    const getFiles = useFilesStore(state => state.files);
    const removeFile = useFilesStore(state => state.removeFile);

    const handleRemoveFile = (file: CloudFile) => {
        removeFile(file);
    }
    return (
        <footer className="mt-2 py-1 border-t">
            <h3>Files Selected:</h3>
            <ul>
                {getFiles && getFiles.length > 0 && getFiles.map((file, index) => {
                    return (
                        <li key={`file-${index}`} className="py-2 cursor-pointer border-b last:border-0 flex gap-2 group justify-between rounded-md hover:bg-indigo-50 px-4" onClick={() => handleRemoveFile(file)}>
                            <span className="flex gap-2 ">
                                <LinkIcon className="h-6 w-6 inline-block" />
                                <span>{file.name}</span>
                            </span>
                            <button>
                                <XMarkIcon className="h-6 w-6 inline-block group-hover:opacity-100 opacity-0 transition-all" />
                            </button>
                        </li>
                    )
                })}
            </ul>
        </footer>
    )
}

const FileBrowser: React.FunctionComponent<FileBrowserProps> = ({ onClose }) => {
    const { files: nodes } = useFileSystem();

    return (
        <div className="fixed top-0 right-0 left-0 bottom-0 bg-black/10 backdrop-blur-sm grid items-center justify-center">
            <div className="card p-2 max-w-4xl w-[500px]">
                <div className="flex justify-between border-b mb-2">
                    <h1 className="text-xl">File Browser</h1>
                    <button className="text-gray-400 hover:text-gray-500" onClick={onClose}>
                        <XCircleIcon className="h-6 w-6" />
                    </button>
                </div>

                <FileTreeView nodes={nodes} classList="h-[200px] overflow-y-auto" />
                <FilesSelected />
            </div>
        </div>
    );

}

interface FileTreeViewProps {
    nodes: CloudNode[];
    classList?: string;
}

const FileTreeView = ({ nodes, classList }: FileTreeViewProps) => {

    return (
        <div className={clsx("flex flex-col gap-2", classList)}>
            {nodes.map(node => <FileTreeItem key={node.path + node.name} node={node} />)}
        </div>
    );
}

const FileTreeItem = ({ node }: { node: CloudNode }) => {
    const [showChildren, setShowChildren] = useState<boolean>(false);
    const addFile = useFilesStore(state => state.addFile);

    const returnChildren = (node: CloudNode) => {
        const folder = node as CloudFolder
        if (folder.type === "folder" && folder.children) {
            return <FileTreeView nodes={folder.children} classList="pl-4" />
        } else {
            console.log('no children');
        }
    }
    const toggleChildren = () => {
        setShowChildren(!showChildren);
    }

    const handleFileSelect = () => {
        if (node.type === "file") {
            addFile(node as CloudFile);
        }
    }

    const handleClick = () => {
        if (node.type === "folder") {
            toggleChildren();
        } else {
            handleFileSelect();
        }
    }


    return (
        <>
            <div className="flex gap-2 hover:bg-indigo-100" onClick={handleClick}>
                {
                    node.type === "folder" ?
                        showChildren ? <FolderMinusIcon className="h-6 w-6" /> : <FolderPlusIcon className="h-6 w-6" /> :
                        <DocumentIcon className="h-6 w-6" />
                }
                <span>{node.name}</span>
            </div>
            {showChildren ? returnChildren(node) : null}
        </>
    )
}

export default FileBrowser
