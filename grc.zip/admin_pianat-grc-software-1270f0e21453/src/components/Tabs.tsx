import { XMarkIcon } from '@heroicons/react/24/outline';
import Link from 'next/link';
import useTabsStore, { Tab } from '../utils/tabsHook';

const TabElement: React.FC<{ tab: Tab, getActiveTab?: Tab, removeTab: (t: Tab) => void }> = ({ tab, getActiveTab, removeTab }) => {
    return (
        <div className={'flex'} id={tab.id}>
            <Link href={tab.href}>
                <a className={tab.href == getActiveTab?.href ? "radix-tab-active relative" : "radix-tab"}>
                    {tab.name && <span>{tab.name}</span>}
                </a>
            </Link>
            {getActiveTab?.removable && tab.href == getActiveTab.href ? <button type='button' className="radix-tab-close" onClick={() => removeTab(getActiveTab)}><XMarkIcon className='h-6 w-6' /></button> : null}
        </div>
    )
}

const Tabs = () => {
    const getTabs = useTabsStore(state => state.tabs);
    const getActiveTab = useTabsStore(state => state.activeTab);
    const removeTab = useTabsStore(state => state.removeTab);

    return (
        <nav>
            <nav className='bg-[#f4f4f4] flex border-collapse'>
                {getTabs && getTabs.length > 0 && getTabs.map((tab, index) => <TabElement key={index} tab={tab} getActiveTab={getActiveTab} removeTab={removeTab} />)}
            </nav>
        </nav>
    )
}



export default Tabs;