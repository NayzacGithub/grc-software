import { z } from "zod";
import { controlGetAllFilterSchema, createControlInputSchema } from "../../validation/controls";
import { createControlAssessmentInputSchema } from "../../validation/control_assessment";
import { createRouter } from "./context";

export const controlsRouter = createRouter()
    .query("getControl", {
        input: z.object({ controlId: z.string() }),
        async resolve({ ctx, input }) {
            return await ctx.prisma.control.findUnique({
                where: {
                    id: input.controlId
                },
                include: {
                    RiskControl: {
                        include: {
                            risk: {
                                include: {
                                    FunctionRisk: {
                                        include: {
                                            function: true
                                        }
                                    }
                                }
                            }
                        }
                    },
                    ControlAssertion: {
                        orderBy: [{
                            created_at: 'desc',
                        }],
                        take: 1
                    }
                },
            })
        }
    })
    .query("getAll", {
        input: controlGetAllFilterSchema,
        async resolve({ ctx }) {
            const controls = await ctx.prisma.riskControl.findMany({
                include: {
                    control: true,
                    risk: true
                }
            });
            return controls;
        }
    })
    .mutation("createControl", {
        input: createControlInputSchema,
        async resolve({ ctx, input }) {
            const control = await ctx.prisma.control.create({
                data: {
                    id: input.id,
                    name: input.name,
                    description: input.description,
                    type: input.type,
                    method: input.method,
                    frequency: input.frequency,
                    entityLevel: input.entityLevel,
                    controlClassification: input.controlClassification,
                    antiFraud: input.antiFraud == 'true',
                    RiskControl: {
                        create: {
                            risk_id: input.risk_id
                        }
                    },

                }
            });
            return control
        }
    })
    .mutation("assessControl", {
        input: createControlAssessmentInputSchema,
        async resolve({ ctx, input }) {
            const controlAssessment = await ctx.prisma.controlAssertion.create({
                data: {
                    adequacy: input.adequacy == 'true',
                    signiture: input.signiture,
                    design: input.design == 'true',
                    impact: input.impact,
                    recommendations: input.recommendation,
                    Control: {
                        connect: {
                            id: input.control_id,
                        }
                    }
                }
            });
            return controlAssessment;
        }
    })