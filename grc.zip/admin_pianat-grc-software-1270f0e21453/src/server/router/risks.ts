import { createRouter } from "./context";
import z from "zod";
import { riskGetAllFilterSchema } from "../../validation/risks";

export const risksRouter = createRouter()
    .query("getAll", {
        input: riskGetAllFilterSchema,
        async resolve({ ctx }) {
            return await ctx.prisma.risk.findMany({
                include: {
                    FunctionRisk: {
                        include: {
                            function: true,
                        }
                    },

                },
                orderBy: {
                    created_at: "desc",
                }
            });
        }
    })
    .query("getRisk", {
        input: z.object({ riskId: z.string() }),
        async resolve({ ctx, input }) {
            return await ctx.prisma.risk.findUnique({
                where: {
                    id: input.riskId,
                },
                include: {
                    RiskControl: {
                        include: {
                            control: {
                                include: {
                                    ControlAssertion: {
                                        orderBy: {
                                            created_at: 'desc'
                                        },
                                        take: 1,
                                    }
                                }
                            }
                        }
                    },
                    FunctionRisk: {
                        include: {
                            function: true
                        }
                    }
                }
            });
        }
    })
    .mutation("createRisk", {
        input: z.object({
            id: z.string(),
            name: z.string(),
            description: z.optional(z.string()),
            event_type: z.optional(z.enum(['Opportunity_Risk', 'Risk_Of_Uncertainty', 'Risk_Of_Hazards', 'Operational_Risk'])),
            category: z.enum(['Strategic_Risk', 'Operational_Risk', 'Financial_Risk', 'Compliance_Risk', 'Reputational_Risk']),
            impact: z.string(),
            likelihood: z.string(),
            function_id: z.string(),
        }),
        async resolve({ ctx, input }) {
            return await ctx.prisma.risk.create({
                data: {
                    id: input.id,
                    name: input.name,
                    description: input.description,
                    riskType: input.category,
                    event_type: input.event_type,
                    impact: parseInt(input.impact),
                    likelihood: parseInt(input.likelihood),
                    FunctionRisk: {
                        create: {
                            function_id: input.function_id,
                        }
                    }
                }
            })
        }
    })
    .mutation("assessRiskRating", {
        input: z.object({
            risk_id: z.string(),
            likelihood: z.string(),
            impact: z.string(),
            assessing: z.enum(['residual', 'inherent'])
        }),
        async resolve({ ctx, input }) {
            if (input.assessing == 'inherent') {
                const risk = await ctx.prisma.risk.update({
                    where: {
                        id: input.risk_id
                    },
                    data: {
                        likelihood: parseInt(input.likelihood),
                        impact: parseInt(input.impact),
                    }
                });

                return risk;
            } else if (input.assessing == 'residual') {
                const assessment = await ctx.prisma.residualRiskAssessment.create({
                    data: {
                        likelihood: parseInt(input.likelihood),
                        impact: parseInt(input.impact),
                        Risk: {
                            connect: {
                                id: input.risk_id
                            }
                        }
                    },
                });
                return assessment;
            }
        }
    })