import { createFunctionInputSchema } from "../../validation/function";
import { createRouter } from "./context";

export const processesRouter = createRouter()
    .query("getAll", {
        async resolve({ ctx }) {
            return await ctx.prisma.function.findMany({
                include: {
                    _count: {
                    },
                    FunctionRisk: {
                        include: {
                            risk: true
                        }
                    }
                }
            });
        }
    })
    .mutation("create", {
        input: createFunctionInputSchema,
        async resolve({ ctx, input }) {
            return await ctx.prisma.function.create({
                data: {
                    id: input.id,
                    name: input.name,
                    description: input.description
                }
            });
        }
    })
    .query("catalog", {
        async resolve({ ctx }) {
            return await ctx.prisma.function.findMany({});
        }
    })
