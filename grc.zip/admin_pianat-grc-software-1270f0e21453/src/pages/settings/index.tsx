import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutSection } from "../../components/ActionsLayout";

const SettingsPage = () => {
    return (
        <ActionsLayout>
            <ActionsLayoutHeader>
                <h1 className="font-bold text-xl">Settings</h1>
            </ActionsLayoutHeader>
            <ActionsLayoutSection>
                
            </ActionsLayoutSection>

        </ActionsLayout>
    );
}

export default SettingsPage;