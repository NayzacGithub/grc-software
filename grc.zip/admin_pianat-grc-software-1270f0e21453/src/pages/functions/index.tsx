import { NextPage } from "next";
import { trpc } from "../../utils/trpc";
import Head from "next/head";
import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutMain, ActionsLayoutSection} from "../../components/ActionsLayout";
import { useFunctionNavigation } from "../../utils/navHook";

const FunctionsIndex: NextPage = () => {
    const { data } = trpc.useQuery(["processes.catalog"]);
    const { createFunction } = useFunctionNavigation();
    return (
        <ActionsLayout>
            <Head>
                <title>Function Catalog | Pi-Comply</title>
            </Head>
            <ActionsLayoutHeader>
                <h1 className="text-2xl font-bold text-gray-700 my-auto">Function Catalog</h1>
                <button className="bg-blue-500 text-white px-4 py-2 rounded-lg my-auto" onClick={() => createFunction()}>Create Function</button>
            </ActionsLayoutHeader>
            <ActionsLayoutMain>
                <ActionsLayoutSection>
                    <table className="min-w-max w-full bg-white">
                        <thead className="bg-white">
                            <tr>
                                <th className="bg-white border-b-2 border-l px-2 py-2 text-center sticky top-0">Function ID</th>
                                <th className="bg-white border-b-2 border-l px-2 py-2 text-left sticky top-0">Function Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data && data.map(row => {
                                return (
                                    <tr className="hover:bg-gray-100 cursor-pointer" key={row.id}>
                                        <th className="border-b max-h-10 truncate py-1 px-2"><span>{row.id}</span></th>
                                        <td className="border-b max-h-10 truncate py-1 px-2">
                                            <span>
                                                {row.name}
                                            </span>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </ActionsLayoutSection>
            </ActionsLayoutMain>
        </ActionsLayout>
    )
}

export default FunctionsIndex;