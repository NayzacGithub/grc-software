import { NextPage } from "next";
import { trpc } from "../../utils/trpc";
import { FieldErrors, useForm } from "react-hook-form";
import { useState } from "react";
import { ErrorMessage } from '@hookform/error-message';
import Layout from "../../components/Layout";
import Head from "next/head";
import clsx from "clsx";
import { CreateFunctionInput } from "../../validation/function";
import useMainNavigation from "../../utils/mainNavHook";
import { toast } from "react-toastify";
import { useFunctionNavigation } from "../../utils/navHook";


const CreateFunctionPage: NextPage = () => {
    const { register, handleSubmit, formState: { errors } } = useForm<CreateFunctionInput>();
    const [showErrors, setShowErrors] = useState<boolean>(true);
    const { mutateAsync } = trpc.useMutation(["processes.create"]);
    const { switchToCatalog } = useFunctionNavigation();
    const onSubmit = async (data: CreateFunctionInput) => {
        setShowErrors(true);
        try {
            await mutateAsync(data);
        } finally {
            switchToCatalog();
            toast("Function created successfully", { type: "success" });
        }
    }

    const onError = () => {
        toast("There are errors in the form", { type: "error" });
    }

    return (
        <Layout>
            <Head>
                <title>Add New Function | Pi-Comply</title>
            </Head>
            <div className="text-2xl py-4 font-bold text-center">Add Function</div>
            <div className="bg-white rounded-b-lg min-w-4xl max-w-4xl w-full mx-auto shadow-lg">
                <form onSubmit={handleSubmit(onSubmit, onError)}>
                    <section className={clsx("p-5")}>
                        <h1 className="text-2xl font-bold pb-3 border-b">Details</h1>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="id" className="text-lg">Function ID *</label>
                            <input type="text" id="id" {...register('id', { required: "You must include a unique and valid Function ID" })} className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="id"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="name" className="text-lg">Function Name *</label>
                            <input type="text" id="name" {...register('name', { required: "You must include a Function name" })} className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="name"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="description" className="text-lg">Function Description</label>
                            <textarea {...register("description")} id="description" className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="description"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                    </section>
                    <div className="flex p-4 w-full justify-end justify-items-end" >
                        <button type="submit" className="bg-indigo-500 text-white font-bold py-1 ml-auto px-4 rounded-lg text-lg ring-2 mr-auto">Create Function</button>
                    </div>
                </form>
            </div>

        </Layout>
    )
}

export default CreateFunctionPage;