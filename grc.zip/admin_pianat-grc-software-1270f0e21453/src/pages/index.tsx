import type { NextPage } from "next";
import Head from "next/head";
import Layout from "../components/Layout";
import { OrganizationWelcome } from "../components/OrganizationWelcome";
import useMainNavigation from "../utils/mainNavHook";
import { trpc } from "../utils/trpc";

const Home: NextPage = () => {

  const { navigateTo } = useMainNavigation();
  const { data } = trpc.useQuery(['rcm.getDashboardCount']);

  return <>
    <Head>
      <title>Pi-Comply | Dashboard</title>
    </Head>
    <Layout>
      <OrganizationWelcome />
      <main className="px-8 mt-6">
        <h2 className="text-lg font-thin">Here are your quick links 🔗</h2>
        <nav className="grid grid-cols-4 gap-4 mt-2">
          <article className="card p-2 cursor-pointer hover:ring-2 ring-teal-400" onClick={() => navigateTo({ href: '/risks', name: 'Risks Catalog' })}>
            <h3 className="text-lg font-bold">Risks Catalog</h3>
            <p className="text">View all <span className="text-teal-700">{data?.risksCount}</span> risks and their details</p>
          </article>
          <article className="card p-2 cursor-pointer hover:ring-2 ring-teal-400" onClick={() => navigateTo({ href: '/controls', name: 'Controls Catalog' })}>
            <h3 className="text-lg font-bold">Controls Catalog</h3>
            <p className="text">View all <span className="text-teal-700">{data?.controlsCount}</span> controls and their details</p>
          </article>
          <article className="card p-2 cursor-pointer hover:ring-2 ring-teal-400" onClick={() => navigateTo({ href: '/rcm/beta', name: 'RCM' })}>
            <h3 className="text-lg font-bold">RCM</h3>
            <p className="text">View the Risk Control Matrix</p>
          </article>
          <div className=""></div>
          <article className="card p-2 cursor-pointer hover:ring-2 ring-teal-400" onClick={() => navigateTo({ href: '/functions', name: 'Functions' })}>
            <h3 className="text-lg font-bold">Functions Catalog</h3>
            <p className="text">View the Functions Catalog</p>
          </article>
        </nav>
      </main>
    </Layout>
  </>

};

export default Home;
