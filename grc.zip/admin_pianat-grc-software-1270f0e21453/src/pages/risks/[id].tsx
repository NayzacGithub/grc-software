import { useRouter } from "next/router";
import { trpc } from "../../utils/trpc";
import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutMain, ActionsLayoutSection, ActionsLayoutSide } from "../../components/ActionsLayout";
import clsx from "clsx";
import { useControlNavigation, useRiskNavigation } from "../../utils/navHook";
import Head from "next/head";

const RiskPage = () => {
    const { navigateTo } = useControlNavigation();
    const { assessRisk } = useRiskNavigation();
    const router = useRouter();
    const { id } = router.query;
    const { data: risk, isLoading, status } = trpc.useQuery(['risks.getRisk', { riskId: id as string }]);

    if (isLoading) {
        return <ActionsLayout><div>Loading...</div></ActionsLayout>
    }

    if (status == "error" || !risk) {
        return <ActionsLayout><div>Error...</div></ActionsLayout>
    }
    const RiskRatings = ['Very Low', 'Low', 'Medium', 'High', 'Very High'];
    const bgColors = ['bg-green-500', 'bg-green-400', 'bg-yellow-400', 'bg-orange-400', 'bg-red-500'];


    return (
        <ActionsLayout>
            <Head>
                <title>{risk.name} - Pianat</title>
            </Head>
            <ActionsLayoutHeader>
                <div className="flex flex-col">
                    <span className="text-sm">Risk</span>
                    <h1 className="text-2xl">
                        {risk?.id}
                    </h1>
                </div>
                <div className="flex gap-5">
                    <div className="flex flex-col ">
                        <span className="text-sm">Owner</span>
                        <h1 className="text-lg">
                            User
                        </h1>
                    </div>
                    <div className="flex flex-col gap-1 ">
                        <span className="text-sm">Status</span>
                        <h1 className="text-sm">
                            <span className="bg-cyan-500 text-white px-1 py-1 rounded-lg">Approved</span>
                        </h1>
                    </div>
                </div>
                <button className="bg-blue-500 text-white  px-4 py-3  rounded-lg flex gap-2 my-auto" onClick={() => assessRisk(risk.id)}><span className="my-auto">Start Risk Assessment</span></button>
            </ActionsLayoutHeader>
            <ActionsLayoutMain>
                <ActionsLayoutSection>
                    <div className="p-5">
                        <details open className=" pb-5">
                            <summary className="text-2xl font-bold">General</summary>
                            <div className="flex flex-col gap-2 justify-between pt-4">
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Risk ID</span>
                                    <span>{risk.id}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Description</span>
                                    <span className=" whitespace-pre-wrap">{risk.description}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Owner</span>
                                    <span>{`User`}</span>
                                </div>
                            </div>
                        </details>
                        <details open className=" border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Risk Indicators / Incidents</summary>
                            <div className="flex justify-around  pt-4">
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Associated Losses</span>
                                    <span className="bg-green-700 text-white rounded-full px-4 pb-1 max-w-fit">{0}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Open Issues</span>
                                    <span className="bg-green-700 text-white rounded-full px-4 pb-1 max-w-fit">{0}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Indicators in breach</span>
                                    <span className="bg-green-700 text-white rounded-full px-4 pb-1 max-w-fit">{0}</span>
                                </div>
                            </div>
                        </details>
                        <details open className=" border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Inherent Risk Assessment</summary>
                            <div className="flex justify-around pt-4">
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Inherent Impact</span>
                                    <span className={clsx("text-white rounded-full px-4 pb-1 max-w-fit", risk.impact != null ? bgColors[risk.impact - 1] : 'bg-gray-400')}>{risk.impact ? RiskRatings[risk.impact - 1] : 'N/A'}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Likelihood Impact</span>
                                    <span className={clsx("text-white rounded-full px-4 pb-1 max-w-fit", risk.likelihood != null ? bgColors[risk.likelihood - 1] : 'bg-gray-400')}>{risk.likelihood ? RiskRatings[risk.likelihood - 1] : 'N/A'}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Inherent Risk Rating</span>
                                    <span className={clsx("text-white rounded-full px-4 pb-1 max-w-fit",
                                        risk.likelihood != null && risk.impact != null ?
                                            bgColors[Math.round(((risk.likelihood - 1) + (risk.impact - 1)) / 2)]
                                            : 'bg-gray-400')}>
                                        {risk.likelihood != null && risk.impact != null ?
                                            RiskRatings[Math.round(((risk.likelihood - 1) + (risk.impact - 1)) / 2)]
                                            : 'N/A'}
                                    </span>
                                </div>
                            </div>

                            <div className="grid py-4 gap-4">
                                <details className="bg-white border-teal-700 border-2 border-l-8 p-3" open>
                                    <summary className="font-bold mb-2">Impact Guidance</summary>
                                    <p className="mb-1">When Estimating impact, the following should be considered</p>
                                    <ul className="ml-5">
                                        <li className=" list-decimal">The expected level of disruption to business operations or applications;</li>
                                        <li className=" list-decimal">The potential for negative media coverage or reputational damage;</li>
                                        <li className=" list-decimal">The potential for loss of customer confidence or loss of customers; and</li>
                                        <li className=" list-decimal">The degree of loss or sanctions that may be imposed by regulators.</li>
                                    </ul>
                                </details>
                                <details className="bg-white border-teal-700 border-2 border-l-8 p-3" open>
                                    <summary className="font-bold mb-2">Probablity Guidance</summary>
                                    <p className="mb-1">Estimating the Probablity can be facilitated by considering, for example:</p>
                                    <ul className="ml-5 list-disc">
                                        <li className=" list-item">The frequency of the process (if the process is completed more frequently, it may increase the probability of an event/risk occuring); and</li>
                                        <li className=" list-item">The frequency of past events (i.e if the risk has occured twice in the last month, it may increase the probability of a repeat occurrance)</li>
                                    </ul>
                                </details>
                                <div>
                                    <h2 className="text-xl font-bold">Mitigating Controls</h2>
                                    <table className="bg-white w-full table-auto border mt-3">
                                        <thead>
                                            <tr>
                                                <th className="bg-[#dbdbdb]/30 border-x py-4">ID</th>
                                                <th className="bg-[#dbdbdb]/30 border-x py-4">Executor</th>
                                                <th className="bg-[#dbdbdb]/30 border-x py-4">Design Effectiveness</th>
                                                <th className="bg-[#dbdbdb]/30 border-x py-4">Adequacy</th>
                                                <th className="bg-[#dbdbdb]/30 border-x py-4">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {risk.RiskControl.length > 0 && risk.RiskControl.map((riskControl) => {
                                                return (
                                                    <tr className="border-b border-gray-100 hover:bg-slate-100 cursor-pointer" key={`${riskControl.risk_id}-${riskControl.control_id}`} onClick={() => navigateTo(riskControl.control_id, riskControl.risk_id)}>
                                                        <td className="text-center py-5 border-x">{riskControl.control_id}</td>
                                                        <td className="text-center py-5 border-x">{`User`}</td>
                                                        <td className="text-center py-5 border-x"><span className={clsx(riskControl.control.ControlAssertion[0]?.design ? "bg-green-500" : "bg-red-500", "text-white py-1 px-4 rounded-full")}>{(riskControl.control.ControlAssertion[0]?.design ? 'Effective' : 'Not Effective') || 'N/A'}</span></td>
                                                        <td className="text-center py-5 border-x"><span className={clsx(riskControl.control.ControlAssertion[0]?.adequacy ? "bg-green-500" : "bg-red-500", "text-white py-1 px-4 rounded-full")}>{(riskControl.control.ControlAssertion[0]?.adequacy ? 'Adequate' : 'Inadequate') || 'N/A'}</span></td>
                                                        <td className="text-center py-5 border-x"><span className="bg-indigo-500 text-white py-1 px-4 rounded-full">Approved</span></td>
                                                    </tr>
                                                )
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </details>
                    </div>
                </ActionsLayoutSection>
                <ActionsLayoutSide>
                    <div className="card py-3 px-5 flex flex-col gap-2">
                        <div className="grid grid-cols-3">
                            <h3 className="font-semibold">
                                Stage
                            </h3>
                            <p className=" col-span-2">Inherent Risk Assessment (Inherent Assessment)</p>
                        </div>
                        <div className="grid grid-cols-3">
                            <h3 className="font-semibold">
                                Due Date
                            </h3>
                            <p className=" col-span-2">30/11/2022</p>
                        </div>
                    </div>
                    <div className="bg-white border-teal-600 border-2 py-3 px-5">
                        <h2 className="font-bold mb-2">Risk Assessment Guidance</h2>
                        <p className="mb-1">The following guidance should be considered when assessing the risk:</p>
                        <ul className="ml-5 list-disc">
                            <li className=" list-item">The risk should be assessed in the context of the organisation’s risk appetite and tolerance;</li>
                        </ul>
                    </div>
                    {risk?.id == "GBCWCGW001" && <div className="bg-white border-teal-600 border-2 py-3 px-5">
                        <h2 className="font-bold mb-2">Risk Jobs</h2>
                        <ul className="flex flex-col gap-2 mt-2">
                            <div className="border p-2 flex">
                                <div>
                                    <h3 className="font-semibold">Risk Assessment #1</h3>
                                    <p>Due in 14 hours</p>
                                </div>
                                <div className="ml-auto my-auto text-green-600">
                                    Current job
                                </div>
                            </div>
                        </ul>
                    </div>}
                    {risk?.id == "GBCWCGW002" && <div className="bg-white border-teal-600 border-2 py-3 px-5">
                        <h2 className="font-bold mb-2">Risk Jobs</h2>
                        <ul className="flex flex-col gap-2 mt-2">
                            <div className="border p-2 flex">
                                <div>
                                    <h3 className="font-semibold">Risk Assessment #2</h3>
                                    <p>Due in 3 days and 2 hours</p>
                                </div>
                                <div className="ml-auto my-auto text-green-600">
                                    Current job
                                </div>
                            </div>
                        </ul>
                    </div>}
                </ActionsLayoutSide>
            </ActionsLayoutMain>
        </ActionsLayout>
    );
}

export default RiskPage
