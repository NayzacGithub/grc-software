import { NextPage } from "next";
import Head from "next/head";
import Layout from "../../components/Layout";
import { trpc } from "../../utils/trpc";
import { Controller, FieldErrors, useForm } from "react-hook-form";
import { CreateRiskInput } from "../../validation/risks";
import { useState } from "react";
import { ErrorMessage } from '@hookform/error-message';
import { useRiskNavigation } from "../../utils/navHook";
import clsx from "clsx";
import Select from "react-select";
import { toast } from "react-toastify";


const CreateRiskPage: NextPage = () => {
    const { register, handleSubmit, formState: { errors }, watch, setValue, control: formControl } = useForm<CreateRiskInput>({
        mode: "all",
        criteriaMode: "all",
        shouldFocusError: true,
    });
    const [showErrors] = useState<boolean>(true);
    const { data: functions } = trpc.useQuery(["processes.getAll"]);
    const { mutateAsync } = trpc.useMutation(["risks.createRisk"]);
    const { switchToCatalog } = useRiskNavigation();

    const onSubmit = async (data: CreateRiskInput) => {
        try {
            await mutateAsync(data);
        } finally {
            switchToCatalog();
            toast('Risk created successfully', {
                type: 'success',
            });
        }
    }

    const onError = (errors: FieldErrors) => {
        toast(`There are validation errors, Please check the form`, {
            type: 'error',
        });
        console.error(errors);
    }

    const handleRiskRatingBox = (impact: number, likelihood: number) => {
        setValue("impact", impact.toString());
        setValue("likelihood", likelihood.toString());
    }

    type bgColor = 'bg-green-500' | 'bg-green-400' | 'bg-yellow-400' | 'bg-orange-400' | 'bg-red-500' | 'bg-gray-500';

    const calculateRiskColor = (impact: number, likelihood: number): bgColor | undefined => {
        if (impact && likelihood) {
            const risk = Math.round((impact + likelihood) / 2);
            const bgColors = ['bg-green-500', 'bg-green-400', 'bg-yellow-400', 'bg-orange-400', 'bg-red-500'];
            return bgColors[risk - 1] as bgColor;
        }
    }

    return (
        <Layout>
            <Head>
                <title>Add New Risk | Pi-Comply</title>
            </Head>
            <div className="text-2xl py-4 font-bold text-center">Add Risk</div>
            <div className="bg-white rounded-b-lg min-w-4xl max-w-4xl w-full mx-auto shadow-lg">
                <form onSubmit={handleSubmit(onSubmit, onError)}>
                    <section className={clsx("p-5")}>
                        <h1 className="text-2xl font-bold pb-3 border-b">Details</h1>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="id" className="text-lg">Risk ID</label>
                            <input type="text" id="id" {...register('id', { required: "You must include a unique and valid Risk ID" })} className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="id"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="name" className="text-lg">Risk Name</label>
                            <input type="text" id="name" {...register('name', { required: "You must include a risk name" })} className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="name"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="category" className="text-lg">Category</label>
                            <select {...register("category", { required: "You must select a risk type" })} id="category" className="border-gray-300 rounded-lg" >
                                <option value="">Select a risk category</option>
                                <option value="Strategic_Risk">Strategic Risk</option>
                                <option value="Operational_Risk">Operational Risk</option>
                                <option value="Financial_Risk">Financial Risk</option>
                                <option value="Compliance_Risk">Compliance Risk</option>
                                <option value="Reputational_Risk">Reputational Risk</option>
                            </select>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="category"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>

                        {functions && <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="function_id">Function</label>
                            <Controller
                                control={formControl}
                                name="function_id"
                                rules={{ required: "You must select a function" }}
                                render={({ field: { onChange, ref } }) => (
                                    <>
                                        <Select
                                            ref={ref}
                                            options={

                                                functions.map((f) => ({
                                                    value: f.id,
                                                    label: f.name,
                                                }))
                                            }
                                            onChange={(option) => {
                                                if (option?.value)
                                                    onChange(option.value);
                                            }}
                                        />
                                        <ErrorMessage
                                            errors={showErrors ? errors : {}}
                                            name="function_id"
                                            render={({ message }) => <p className="text-red-500">{message}</p>}
                                        /></>
                                )}
                            />
                        </div>}

                        <h1 className="text-2xl font-bold pb-3 border-b">Parameters</h1>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="likelihood" className="text-lg">Likelihood</label>
                            <select {...register("likelihood",)} id="likelihood" className="border-gray-300 rounded-lg">
                                <option value="" className="text-gray-600">Please select a value</option>
                                <option className="text-green-500 font-bold" value="1">1. Rare</option>
                                <option className="text-green-400 font-bold" value="2">2. Unlikely</option>
                                <option className="text-yellow-500 font-bold" value="3">3. Possible</option>
                                <option className="text-orange-500 font-bold" value="4">4. Likely</option>
                                <option className="text-red-500 font-bold" value="5">5. Very Likely</option>
                            </select>
                            <ErrorMessage
                                errors={errors}
                                name="likelihood"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="impact" className="text-lg">Impact</label>
                            <select {...register("impact")} id="impact" className="border-gray-300 rounded-lg">
                                <option value="" className="text-gray-600">Please select a value</option>
                                <option className="text-green-500 font-bold" value="1">1. Very low</option>
                                <option className="text-green-400 font-bold" value="2">2. Low</option>
                                <option className="text-yellow-500 font-bold" value="3">3. Medium</option>
                                <option className="text-orange-500 font-bold" value="4">4. High</option>
                                <option className="text-red-500 font-bold" value="5">5. Very High</option>
                            </select>
                            <ErrorMessage
                                errors={errors}
                                name="impact"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div>
                            <div className="grid grid-cols-5 grid-rows-5 aspect-square gap-1 border-collapse w-[200px] mx-auto" >
                                {
                                    Array(5).fill(0).map((_a, i) => {
                                        return Array(5).fill(0).map((_b, j) => {
                                            return (
                                                <div key={`${i}-${j}`} className={
                                                    clsx(
                                                        'text-white text-center flex justify-center',
                                                        (parseInt(watch("impact")) == j + 1) && (parseInt(watch("likelihood")) == i + 1)
                                                            ? 'ring ring-indigo-600'
                                                            : ''
                                                        ,
                                                        calculateRiskColor((i + 1), (j + 1))
                                                    )
                                                } onClick={() => { handleRiskRatingBox(j + 1, i + 1) }}>
                                                    <span className="my-auto invert">{Math.floor(((j + 1) + (i + 1)) / 2)}</span>
                                                </div>
                                            )
                                        })
                                    })
                                }
                            </div>
                        </div>

                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="description" className="text-lg">Risk Description</label>
                            <textarea {...register("description")} id="description" className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="description"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                    </section>
                    <div className="flex p-4 w-full justify-end justify-items-end" >
                        <button type="submit" className="bg-indigo-500 text-white font-bold py-1 ml-auto px-4 rounded-lg text-lg ring-2 mr-auto">Create Risk</button>
                    </div>
                </form>
            </div>

        </Layout>
    )
}

export default CreateRiskPage;