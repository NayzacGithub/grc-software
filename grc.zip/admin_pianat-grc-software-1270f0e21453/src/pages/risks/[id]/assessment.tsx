import { useRouter } from "next/router";
import { trpc } from "../../../utils/trpc";
import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutMain } from "../../../components/ActionsLayout";
import { useControlNavigation } from "../../../utils/navHook";
import { useForm } from "react-hook-form";
import { AssessRisk } from "../../../validation/risks";
import clsx from "clsx";


const RiskAssessmentPage = () => {
    const router = useRouter();
    const { id } = router.query;
    const { data: risk, isLoading, status, refetch } = trpc.useQuery(['risks.getRisk', { riskId: id as string }]);

    const { mutateAsync } = trpc.useMutation('risks.assessRiskRating');

    const { register, handleSubmit, watch, setValue } = useForm<AssessRisk>();


    const onSubmit = handleSubmit(async (data) => {

        mutateAsync(data).then(() => {
            refetch();
        });

    });

    const handleRiskRatingBox = (impact: number, likelihood: number) => {
        setValue("impact", impact.toString());
        setValue("likelihood", likelihood.toString());
    }

    type bgColor = 'bg-green-500' | 'bg-green-400' | 'bg-yellow-400' | 'bg-orange-400' | 'bg-red-500' | 'bg-gray-500';

    const RiskRatings = ['Very Low', 'Low', 'Medium', 'High', 'Very High'];
    const calculateRiskColor = (impact: number, likelihood?: number): bgColor | undefined => {
        const bgColors = ['bg-green-500', 'bg-green-400', 'bg-yellow-400', 'bg-orange-400', 'bg-red-500'];
        if (impact && likelihood) {
            const risk = Math.round((impact + likelihood) / 2);
            return bgColors[risk - 1] as bgColor;
        } else {
            return bgColors[impact - 1] as bgColor;
        }
    }

    const { navigateTo } = useControlNavigation();
    if (isLoading) {
        return <ActionsLayout><div>Loading...</div></ActionsLayout>
    }

    if (status == "error" || !risk) {
        return <ActionsLayout><div>Error...</div></ActionsLayout>
    }



    return (
        <ActionsLayout>
            <ActionsLayoutHeader>
                <div className="flex flex-col ">
                    <span className="text-sm">Risk Assessment</span>
                    <h1 className="text-2xl">
                        {risk?.id} - <span className="font-bold"> Assessment #1</span>
                    </h1>
                </div>
                <div className="flex gap-5">
                    <div className="flex flex-col ">
                        <span className="text-sm">Owner</span>
                        <h1 className="text-lg">
                            User
                        </h1>
                    </div>
                    <div className="flex flex-col gap-1 ">
                        <span className="text-sm">Status</span>
                        <h1 className="text-sm">
                            <span className="bg-red-500 text-white px-1 py-1 rounded-lg">Awaiting Assessment</span>
                        </h1>
                    </div>
                </div>

            </ActionsLayoutHeader>
            <ActionsLayoutMain>
                <div className="grid grid-cols-3 gap-5">
                    <div className="p-5 bg-white max-h-fit">
                        <h1 className="text-xl font-bold">
                            Mitigating controls
                        </h1>
                        <ul className="grid gap-4 mt-2 max-h-fit overflow-y-auto">
                            {risk.RiskControl.map(rc => (
                                <li key={`${rc.risk_id}-${rc.control_id}`} className="bg-gray-50 p-4 cursor-pointer hover:bg-gray-100" onClick={() => navigateTo(rc.control_id)} >
                                    <h1 className="font-semibold">{rc.control.id}</h1>
                                    <h2>
                                        {rc.control.name}
                                    </h2>
                                    <div className="flex gap-2">
                                        <div className={clsx(rc.control.ControlAssertion[0]?.design ? 'bg-green-300' : 'bg-red-300' || 'bg-gray-300', "px-2 py-1 rounded-lg")}>Design: {rc.control.ControlAssertion[0]?.design ? 'Effective' : 'Not Effective' || 'N/A'}</div>
                                        <div className={clsx(rc.control.ControlAssertion[0]?.adequacy ? 'bg-green-300' : 'bg-red-300' || 'bg-gray-300', "px-2 py-1 rounded-lg")}>Adequacy: {rc.control.ControlAssertion[0]?.adequacy ? 'Adequate' : 'Not Adequate' || 'N/A'}</div>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="p-5 bg-white">
                        <details open className=" pb-5">
                            <summary className="text-2xl font-bold">General</summary>
                            <div className="flex flex-col gap-2 justify-between pt-4">
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Risk ID</span>
                                    <span>{risk.id}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Description</span>
                                    <span className=" whitespace-pre-wrap">{risk.description}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Owner</span>
                                    <span>{`User`}</span>
                                </div>
                            </div>
                        </details>
                        <details className=" border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Reassessment Triggers</summary>
                            <div className="flex justify-around  pt-4">
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Associated Losses</span>
                                    <span className="bg-green-700 text-white rounded-full px-4 pb-1 max-w-fit">{0}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Open Issues</span>
                                    <span className="bg-green-700 text-white rounded-full px-4 pb-1 max-w-fit">{0}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Indicators in breach</span>
                                    <span className="bg-green-700 text-white rounded-full px-4 pb-1 max-w-fit">{0}</span>
                                </div>
                            </div>
                        </details>
                        <details open className=" border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Inherent Risk Assessment</summary>
                            {risk.impact && risk.likelihood && <div className="flex justify-around pt-4">
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Inherent Impact</span>
                                    <span className={clsx("text-white rounded-full px-4 pb-1 max-w-fit font-bold", risk.impact != null ? calculateRiskColor(risk.impact) : 'bg-gray-400')}>{risk.impact ? RiskRatings[risk.impact - 1] : 'N/A'}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Inherent Likelihood </span>
                                    <span className={clsx("text-white rounded-full px-4 pb-1 max-w-fit font-bold", risk.likelihood != null ? calculateRiskColor(risk.likelihood) : 'bg-gray-400')}>{risk.likelihood ? RiskRatings[risk.likelihood - 1] : 'N/A'}</span>
                                </div>
                                <div className="flex flex-col gap-1 items-center">
                                    <span className="font-bold">Inherent Risk Rating</span>
                                    <span className={clsx("text-white rounded-full px-4 pb-1 max-w-fit font-bold", risk.likelihood != null ? calculateRiskColor(risk.likelihood) : 'bg-gray-400')}>{risk.likelihood && risk.impact ? RiskRatings[Math.round((risk.likelihood + risk.impact) / 2)] : 'N/A'}</span>
                                </div>
                            </div>}
                            {!risk.impact && !risk.likelihood &&
                                <form onSubmit={onSubmit}>
                                    <input type="text" {...register("assessing")} value={'inherent'} readOnly className="hidden" />
                                    <input type="text" {...register("risk_id")} value={risk.id} readOnly className="hidden" />
                                    <div className="flex flex-col gap-1 py-2">
                                        <label htmlFor="likelihood" className="text-lg">Likelihood</label>
                                        <select {...register("likelihood")} id="likelihood" className="border-gray-300 rounded-lg">
                                            <option value="" className="text-gray-600">Please select a value</option>
                                            <option className="text-green-500 font-bold" value="1">1. Rare</option>
                                            <option className="text-green-400 font-bold" value="2">2. Unlikely</option>
                                            <option className="text-yellow-500 font-bold" value="3">3. Possible</option>
                                            <option className="text-orange-500 font-bold" value="4">4. Likely</option>
                                            <option className="text-red-500 font-bold" value="5">5. Very Likely</option>
                                        </select>
                                    </div>
                                    <div className="flex flex-col gap-1 py-2">
                                        <label htmlFor="impact" className="text-lg">Impact</label>
                                        <select {...register("impact")} id="impact" className="border-gray-300 rounded-lg">
                                            <option value="" className="text-gray-600">Please select a value</option>
                                            <option className="text-green-500 font-bold" value="1">1. Very low</option>
                                            <option className="text-green-400 font-bold" value="2">2. Low</option>
                                            <option className="text-yellow-500 font-bold" value="3">3. Medium</option>
                                            <option className="text-orange-500 font-bold" value="4">4. High</option>
                                            <option className="text-red-500 font-bold" value="5">5. Very High</option>
                                        </select>
                                    </div>
                                    <div>
                                        <div className="grid grid-cols-5 grid-rows-5 aspect-square gap-1 border-collapse w-[200px] mx-auto" >
                                            {
                                                Array(5).fill(0).map((_a, i) => {
                                                    return Array(5).fill(0).map((_b, j) => {
                                                        return (
                                                            <div key={`${i}-${j}`} className={
                                                                clsx(
                                                                    'text-white text-center flex justify-center',
                                                                    (parseInt(watch("impact")) == j + 1) && (parseInt(watch("likelihood")) == i + 1)
                                                                        ? 'ring ring-indigo-600'
                                                                        : ''
                                                                    ,
                                                                    calculateRiskColor((i + 1), (j + 1))
                                                                )
                                                            } onClick={() => { handleRiskRatingBox(j + 1, i + 1) }}>
                                                                <span className="my-auto invert">{Math.floor(((j + 1) + (i + 1)) / 2)}</span>
                                                            </div>
                                                        )
                                                    })
                                                })
                                            }
                                        </div>
                                    </div>
                                    <div className="flex justify-center pt-4">
                                        <button type="submit" className="bg-green-500 text-white rounded-full px-4 pb-1 max-w-fit">Save</button>
                                    </div>
                                </form>
                            }
                        </details>
                        <details open className="border-t-2">
                            <summary className="text-2xl font-bold ">Residual Risk Assessment</summary>
                            {risk.impact && risk.likelihood &&
                                <form onSubmit={onSubmit}>
                                    <input type="text" {...register("assessing")} value={'residual'} readOnly className="hidden" />
                                    <input type="text" {...register("risk_id")} value={risk.id} readOnly className="hidden" />
                                    <div className="flex flex-col gap-1 py-2">
                                        <label htmlFor="likelihood" className="text-lg">Likelihood</label>
                                        <select {...register("likelihood")} id="likelihood" className="border-gray-300 rounded-lg">
                                            <option value="" className="text-gray-600">Please select a value</option>
                                            <option className="text-green-500 font-bold" value="1">1. Rare</option>
                                            <option className="text-green-400 font-bold" value="2">2. Unlikely</option>
                                            <option className="text-yellow-500 font-bold" value="3">3. Possible</option>
                                            <option className="text-orange-500 font-bold" value="4">4. Likely</option>
                                            <option className="text-red-500 font-bold" value="5">5. Very Likely</option>
                                        </select>
                                    </div>
                                    <div className="flex flex-col gap-1 py-2">
                                        <label htmlFor="impact" className="text-lg">Impact</label>
                                        <select {...register("impact")} id="impact" className="border-gray-300 rounded-lg">
                                            <option value="" className="text-gray-600">Please select a value</option>
                                            <option className="text-green-500 font-bold" value="1">1. Very low</option>
                                            <option className="text-green-400 font-bold" value="2">2. Low</option>
                                            <option className="text-yellow-500 font-bold" value="3">3. Medium</option>
                                            <option className="text-orange-500 font-bold" value="4">4. High</option>
                                            <option className="text-red-500 font-bold" value="5">5. Very High</option>
                                        </select>
                                    </div>
                                    <div>
                                        <div className="grid grid-cols-5 grid-rows-5 aspect-square gap-1 border-collapse w-[200px] mx-auto" >
                                            {
                                                Array(5).fill(0).map((_a, i) => {
                                                    return Array(5).fill(0).map((_b, j) => {
                                                        return (
                                                            <div key={`${i}-${j}`} className={
                                                                clsx(
                                                                    'text-white text-center flex justify-center',
                                                                    (parseInt(watch("impact")) == j + 1) && (parseInt(watch("likelihood")) == i + 1)
                                                                        ? 'ring ring-indigo-600'
                                                                        : ''
                                                                    ,
                                                                    calculateRiskColor((i + 1), (j + 1))
                                                                )
                                                            } onClick={() => { handleRiskRatingBox(j + 1, i + 1) }}>
                                                                <span className="my-auto invert">{Math.floor(((j + 1) + (i + 1)) / 2)}</span>
                                                            </div>
                                                        )
                                                    })
                                                })
                                            }
                                        </div>
                                    </div>
                                    <div className="flex justify-center pt-4">
                                        <button type="submit" className="bg-green-500 text-white rounded-full px-4 pb-1 max-w-fit">Complete assessment</button>
                                    </div>
                                </form>
                            }
                        </details>
                    </div>
                    <div className="flex flex-col gap-4">
                        <div className="bg-white border-teal-600 border-2 border-l-8 py-3 px-5">
                            <h2 className="font-bold mb-2">Risk Assessment Guidance</h2>
                            <p className="mb-1">The following guidance should be considered when assessing the risk:</p>
                            <ul className="ml-5 list-disc">
                                <li className=" list-item">The risk should be assessed in the context of the organisation’s risk appetite and tolerance;</li>
                            </ul>
                        </div>
                        <details className="bg-white border-teal-700 border-2 border-l-8 p-3" open>
                            <summary className="font-bold mb-2">Impact Guidance</summary>
                            <p className="mb-1">When Estimating impact, the following should be considered</p>
                            <ul className="ml-5">
                                <li className=" list-decimal">The expected level of disruption to business operations or applications;</li>
                                <li className=" list-decimal">The potential for negative media coverage or reputational damage;</li>
                                <li className=" list-decimal">The potential for loss of customer confidence or loss of customers; and</li>
                                <li className=" list-decimal">The degree of loss or sanctions that may be imposed by regulators.</li>
                            </ul>
                        </details>
                        <details className="bg-white border-teal-700 border-2 border-l-8 p-3" open>
                            <summary className="font-bold mb-2">Probablity Guidance</summary>
                            <p className="mb-1">Estimating the Probablity can be facilitated by considering, for example:</p>
                            <ul className="ml-5 list-disc">
                                <li className=" list-item">The frequency of the process (if the process is completed more frequently, it may increase the probability of an event/risk occuring); and</li>
                                <li className=" list-item">The frequency of past events (i.e if the risk has occured twice in the last month, it may increase the probability of a repeat occurrance)</li>
                            </ul>
                        </details>
                    </div>
                </div>
            </ActionsLayoutMain>
        </ActionsLayout>
    );
}

export default RiskAssessmentPage
