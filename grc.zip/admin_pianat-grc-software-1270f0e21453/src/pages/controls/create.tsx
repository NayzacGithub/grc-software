import { NextPage } from "next";
import { trpc } from "../../utils/trpc";
import { useForm, Controller, FieldErrors } from "react-hook-form";
import { useState } from "react";
import { ErrorMessage } from '@hookform/error-message';
import { useControlNavigation } from "../../utils/navHook";
import { CreateControlInput } from "../../validation/controls";
import Select from "react-select";
import Layout from "../../components/Layout";
import Head from "next/head";
import clsx from "clsx";
import { toast } from "react-toastify";


const CreateControlPage: NextPage = () => {
    const { register, handleSubmit, formState: { errors }, control } = useForm<CreateControlInput>();
    const [showErrors, setShowErrors] = useState<boolean>(true);
    const { data: risks } = trpc.useQuery(["risks.getAll", {}]);
    const { mutateAsync } = trpc.useMutation(["controls.createControl"]);
    const { navigateTo } = useControlNavigation();

    const onSubmit = async (data: CreateControlInput) => {
        setShowErrors(true);
        try {
            const control = await mutateAsync(data);
            navigateTo(control.id);
        } finally {
        }
    }

    const onError = () => {
        toast("There are errors in the form", { type: "error" });
    }

    return (
        <Layout>
            <Head>
                <title>Add New Control | Pi-Comply</title>
            </Head>
            <div className="text-2xl py-4 font-bold text-center">Add Control</div>
            <div className="bg-white rounded-b-lg min-w-4xl max-w-4xl w-full mx-auto shadow-lg">
                <form onSubmit={handleSubmit(onSubmit, onError)}>
                    <section className={clsx("p-5")}>
                        <h1 className="text-2xl font-bold pb-3 border-b">Details</h1>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="id" className="text-lg">Control ID *</label>
                            <input type="text" id="id" {...register('id', { required: "You must include a unique and valid Control ID" })} className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="id"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="name" className="text-lg">Control Name *</label>
                            <input type="text" id="name" {...register('name', { required: "You must include a Control name" })} className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="name"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="description" className="text-lg">Control Description</label>
                            <textarea {...register("description")} id="description" className="border-gray-300 rounded-lg" />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="description"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="risk_id" className="text-lg">Risk</label>
                            <Controller
                                control={control}
                                name="risk_id"
                                rules={{ required: "You must select a Risk" }}
                                render={({ field: { onChange, ref } }) => (
                                    <>
                                        <Select
                                            ref={ref}

                                            options={
                                                risks?.map((f) => ({
                                                    value: f.id,
                                                    label: `${f.id} - ${f.name}`,
                                                }))
                                            }
                                            onChange={(option) => {
                                                if (option?.value)
                                                    onChange(option.value);
                                            }}
                                        />
                                    </>
                                )}
                            />
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="risk_id"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="type" className="text-lg">Type</label>
                            <select {...register("type", { required: "You must select a type " })} id="type" className="border-gray-300 rounded-lg">
                                <option value="">Please select a value</option>
                                <option value="PREVENTIVE">Preventive</option>
                                <option value="DETECTIVE">Detective</option>
                                <option value="CORRECTIVE">Corrective</option>
                                <option value="DIRECTIVE">Directive</option>
                            </select>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="type"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />

                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="method" className="text-lg">Method</label>
                            <select {...register("method", { required: 'You must select a method' })} id="method" className="border-gray-300 rounded-lg">
                                <option value="">Please select a value</option>
                                <option value="MANUAL">Manual</option>
                                <option value="AUTOMATED">Automated</option>
                                <option value="PARTIALY_AUTOMATED">Partialy Automated</option>
                            </select>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="method"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="frequency" className="text-lg">Frequency</label>
                            <select {...register("frequency", { required: 'You must select a control frequency value' })} id="frequency" className="border-gray-300 rounded-lg">
                                <option value="">Please select a value</option>
                                <option value="YEARLY"> Yearly</option>
                                <option value="QUARTERLY">Quarterly</option>
                                <option value="MONTHLY">Monthly</option>
                                <option value="WEEKLY">Weekly</option>
                                <option value="DAILY">Daily</option>
                                <option value="TRANSACTION_EVENT_DRIVEN">Transaction Event Driven</option>
                            </select>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="frequency"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="entityLevel" className="text-lg">Entity level</label>
                            <select {...register("entityLevel", { required: 'You must choose entity level' })} id="entityLevel" className="border-gray-300 rounded-lg">
                                <option value="">Please select a value</option>
                                <option value="PLC">PLC - Process Level Control</option>
                                <option value="ELC">ELC - Entity Level Control</option>
                                <option value="TLC">TLC - Transaction Level Control</option>
                            </select>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="entityLevel"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <span>Control Classification</span>
                            <div className="flex gap-6">
                                <label>
                                    <input {...register("controlClassification", { required: 'You must classify the control' })} type="radio" value="Compensatory" />
                                    <span className="ml-2">Compensatory</span>
                                </label>
                                <label>
                                    <input {...register("controlClassification", { required: 'You must classify the control' })} type="radio" value="Complimentary" />
                                    <span className="ml-2">Complimentary</span>
                                </label>
                                <label>
                                    <input {...register("controlClassification", { required: 'You must classify the control' })} type="radio" value="Key" />
                                    <span className="ml-2">Key</span>
                                </label>
                            </div>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="controlClassification"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                        <div className="flex flex-col gap-1 py-2">
                            <label htmlFor="antiFraud" className="text-lg">
                                <span>Anti-Fraud?</span>
                            </label>
                            <label>
                                <input {...register("antiFraud", { required: 'You must select a value for anti-fraud' })} type="radio" className="mr-2" value="true" />
                                Yes
                            </label>
                            <label>
                                <input {...register("antiFraud", { required: 'You must select a value for anti-fraud' })} type="radio" className="mr-2" value="false" />
                                No
                            </label>
                            <ErrorMessage
                                errors={showErrors ? errors : {}}
                                name="antiFraud"
                                render={({ message }) => <p className="text-red-500">{message}</p>}
                            />
                        </div>
                    </section>
                    <div className="flex p-4 w-full justify-end justify-items-end" >
                        <button type="submit" className="bg-indigo-500 text-white font-bold py-1 ml-auto px-4 rounded-lg text-lg ring-2 mr-auto">Create Control</button>
                    </div>
                </form>
            </div>

        </Layout>
    )
}

export default CreateControlPage;