import { NextPage } from "next";
import { trpc } from "../../utils/trpc";
import Head from "next/head";
import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutMain, ActionsLayoutSection, ActionsLayoutSide } from "../../components/ActionsLayout";
import { useControlNavigation } from "../../utils/navHook";

const ControlsIndex: NextPage = () => {
    const { data } = trpc.useQuery(["controls.getAll", {}]);
    const { navigateTo, createControl } = useControlNavigation();
    return (
        <ActionsLayout>
            <Head>
                <title>Control Catalog | Pi-Comply</title>
            </Head>
            <ActionsLayoutHeader>
                <h1 className="text-2xl font-bold text-gray-700 my-auto">Control Catalog</h1>

                <button className="bg-blue-500 text-white px-4 py-2 rounded-lg my-auto" onClick={createControl} role={'form'} >Create Control</button>

            </ActionsLayoutHeader>
            <ActionsLayoutMain>
                <ActionsLayoutSection>
                    <table className="min-w-max rounded-md w-full sticky top-10 bg-white">
                        <thead className="bg-white">
                            <tr>
                                <th className="bg-white border-b-2 border-l px-2 py-2 text-center sticky top-0">Risk ID</th>
                                <th className="bg-white border-b-2 border-l px-2 py-2 text-center sticky top-0">ID</th>
                                <th className="bg-white border-b-2 border-l px-2 py-2 text-left sticky top-0">Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data && data.map(_rc => {
                                return (
                                    <tr className="hover:bg-gray-100 cursor-pointer" key={`${_rc.risk_id}-${_rc.control_id}`} onClick={() => navigateTo(_rc.control_id)}>
                                        <th className="border-b max-h-10 truncate py-1 px-2">
                                            <span>{_rc.risk_id}</span>
                                        </th>
                                        <th className="border-b max-h-10 truncate py-1 px-2">
                                            <span>
                                                {_rc.control_id}
                                            </span>
                                        </th>
                                        <td className="border-b max-h-10 truncate py-1 px-2">
                                            <span>
                                                {_rc.control.name}
                                            </span>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </ActionsLayoutSection>
            </ActionsLayoutMain>
        </ActionsLayout>
    )
}

export default ControlsIndex;