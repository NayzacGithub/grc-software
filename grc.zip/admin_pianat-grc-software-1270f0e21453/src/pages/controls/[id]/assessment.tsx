import { useRouter } from "next/router";
import { trpc } from "../../../utils/trpc";
import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutMain } from "../../../components/ActionsLayout";
import SigningBoard from "../../../components/SigningBoard";
import { Controller, useForm } from "react-hook-form";
import { useState } from "react";
import FileBrowser from "../../../components/modals/FileBrowser";
import { CreateControlAssessmentInput } from "../../../validation/control_assessment";


const ControlAssessmentPage = () => {
    const router = useRouter();
    const { id } = router.query;
    const { data: control, isLoading, status } = trpc.useQuery(['controls.getControl', { controlId: id as string }]);
    const { mutateAsync } = trpc.useMutation(['controls.assessControl'])
    const [showFileBrowser, setShowFileBrowser] = useState<boolean>(false);
    const { register, handleSubmit, control: formControl } = useForm<CreateControlAssessmentInput>();

    if (isLoading) {
        return <ActionsLayout><div>Loading...</div></ActionsLayout>
    }

    if (status == "error" || !control) {
        return <ActionsLayout><div>Error...</div></ActionsLayout>
    }


    const createAssessment = (data: CreateControlAssessmentInput) => {
        mutateAsync({
            ...data
        }).then(() => {
            router.push(`/controls/${control.id}`)
        })
    }

    const closeFileBrowser = () => setShowFileBrowser(false);

    return (
        <ActionsLayout>
            <ActionsLayoutHeader>
                <div className="flex flex-col">
                    <span className="text-sm">Control Assessment</span>
                    <h1 className="text-2xl">
                        {control?.id} - <span className="font-bold"> Assessment</span>
                    </h1>
                </div>
                <div className="flex gap-5">
                    <div className="flex flex-col ">
                        <span className="text-sm">Owner</span>
                        <h1 className="text-lg">
                            User
                        </h1>
                    </div>
                    {/* <div className="flex flex-col gap-1 ">
                        <span className="text-sm">Status</span>
                        <h1 className="text-sm">
                            <span className="bg-red-500 text-white px-1 py-1 rounded-lg">Awaiting Assessment</span>
                        </h1>
                    </div> */}
                </div>
            </ActionsLayoutHeader>
            <ActionsLayoutMain>
                <main className="grid grid-cols-3 gap-4 w-full">
                    <article className="p-5 card h-fit">
                        <details open className="pb-5">
                            <summary className="text-2xl font-bold">General</summary>
                            <div className="flex flex-col gap-2 justify-between pt-4">
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Control ID</span>
                                    <span>{control.id}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Description</span>
                                    <span className=" whitespace-pre-wrap">{control.description}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Owner</span>
                                    <span>{`User`}</span>
                                </div>
                            </div>
                        </details>
                    </article>
                    <div className="p-5 card">
                        <h1 className="text-2xl font-bold mb-2">Working Paper</h1>
                        <form className="flex flex-col gap-2" onSubmit={handleSubmit(createAssessment)}>
                            <div className="flex flex-col gap-1">
                                <span className="font-bold">Process</span>
                                <input type={'text'} value={control.RiskControl?.at(0)?.risk.FunctionRisk[0]?.function.name} disabled className="pFormInput " />
                            </div>
                            <div className="flex flex-col gap-1">
                                <span className="font-bold">Auditor Name</span>
                                <input type={'text'} value="User" disabled className="pFormInput " />
                            </div>
                            <div className="flex flex-col gap-1 pb-5 border-b-2">
                                <span className="font-bold">Control ID</span>
                                <input type={'text'} {...register('control_id')} defaultValue={control.id} readOnly className="pFormInput " />
                            </div>
                            <div className="flex flex-col gap-1">
                                <span className="font-bold">Design Effectiveness</span>
                                <select {...register('design')} className="pFormInput ">
                                    <option value="" selected>Select a value --</option>
                                    <option value="true">Effective</option>
                                    <option value="false">Defective</option>
                                </select>
                            </div>
                            <div className="flex flex-col gap-1">
                                <span className="font-bold">Adequacy</span>
                                <select {...register('adequacy')} className="pFormInput ">
                                    <option value="" selected>Select a value --</option>
                                    <option value="true">Adequate</option>
                                    <option value="false">Not Adequate</option>
                                </select>
                            </div>
                            <div className="flex flex-col gap-1">
                                <span className="font-bold">Impact</span>
                                <textarea {...register('impact')} className="pFormInput " />
                            </div>
                            <div className="flex flex-col gap-1">
                                <span className="font-bold">Recommendations</span>
                                <textarea {...register('recommendation')} className="pFormInput " />
                            </div>
                            {/* <div className="flex flex-col gap-1">
                                    <span className="font-bold">Attachments</span>
                                    <button onClick={openFileBrowser}>Choose file/s</button>
                                </div> */}
                            <div className="flex flex-col gap-1 max-w-fit">
                                <span className="font-bold">Signiture</span>
                                <Controller
                                    control={formControl}
                                    name="signiture"
                                    render={({ field: { onChange } }) => (
                                        <SigningBoard width={250} height={100} onSign={(signiture) => {
                                            if (signiture) {
                                                onChange(signiture);
                                            }
                                        }} />
                                    )}
                                />
                            </div>
                            <button type="submit" className="font-bold bg-blue-500 text-white py-2 hover:bg-blue-400 rounded-lg">Submit test</button>
                        </form>
                    </div>
                    <aside>
                        <div className="bg-white border-teal-600 border-2 border-l-8 py-3 px-5">
                            <h2 className="font-bold mb-2">Control Assessment</h2>
                            <p className="mb-1">Review and update the control information</p>
                            <p className="mb-1">Add, Review, Update test plans and provide Test Results.</p>
                        </div>
                        <div className="card p-5 mt-5">
                            <h2 className="text-lg font-bold">This control mitigates the following risks:</h2>
                            <table className="bg-white w-full table-auto mt-3 border-y border-gray-200">
                                <thead>
                                    <tr>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Risk ID</th>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Risk name</th>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Impact</th>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Likelihood</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        control.RiskControl.map(_rc => (
                                            <tr key={_rc.risk_id} className="hover:bg-indigo-50 cursor-pointer">
                                                <td className="text-center py-5 border-x">{_rc.risk_id}</td>
                                                <td className="text-center py-5 border-x">{_rc.risk.name}</td>
                                                <td className="text-center py-5 border-x">{_rc.risk.impact || 'N/A'}</td>
                                                <td className="text-center py-5 border-x">{_rc.risk.likelihood || 'N/A'}</td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                        </div>
                    </aside>
                </main>
            </ActionsLayoutMain>
            {showFileBrowser && <FileBrowser onClose={closeFileBrowser} />}
        </ActionsLayout>
    );
}

export default ControlAssessmentPage
