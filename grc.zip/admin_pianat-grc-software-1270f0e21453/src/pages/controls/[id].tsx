import { useRouter } from "next/router";
import { trpc } from "../../utils/trpc";
import ActionsLayout, { ActionsLayoutHeader, ActionsLayoutMain, ActionsLayoutSection, ActionsLayoutSide } from "../../components/ActionsLayout";
import useTabsStore from "../../utils/tabsHook";
import { useControlNavigation, useRiskNavigation } from "../../utils/navHook";

const ControlPage = () => {
    const router = useRouter();
    const { id } = router.query;
    const { data: control, isLoading, status } = trpc.useQuery(['controls.getControl', { controlId: id as string }]);
    const activeTab = useTabsStore(state => state.activeTab);
    const { navigateTo } = useRiskNavigation();
    const { testControl } = useControlNavigation();

    if (isLoading) {
        return <div>Loading...</div>
    }

    if (status == "error" || !control) {
        return <div>Error</div>
    }


    return (
        <ActionsLayout>
            <ActionsLayoutHeader>
                <div className="flex flex-col ">
                    <h1 className="text-2xl">
                        {activeTab && activeTab?.meta !== undefined ? <span onClick={() => {
                            if (activeTab.meta && activeTab.meta['fromRiskId'])
                                navigateTo(activeTab.meta['fromRiskId'])
                        }} className="text-gray-600 text-sm fontsemi ">Risk {activeTab.meta['fromRiskId']} / </span> : null} {control.id}
                    </h1>
                </div>
                <div className="flex gap-5">
                    <div className="flex flex-col ">
                        <span className="text-sm">Owner</span>
                        <h1 className="text-lg">
                            User
                        </h1>
                    </div>
                    <div className="flex flex-col gap-1 ">
                        <span className="text-sm">Design Effectiveness</span>
                        <h1 className="text-sm">
                            <span className="bg-green-500 text-white px-1 py-1 rounded-lg">Effective</span>
                        </h1>
                    </div>
                    <div className="flex flex-col gap-1 ">
                        <span className="text-sm">Operating Effectiveness</span>
                        <h1 className="text-sm">
                            <span className="bg-green-500 text-white px-1 py-1 rounded-lg">Effective</span>
                        </h1>
                    </div>
                </div>
                <button className="bg-blue-500 text-white px-4 py-3 rounded-lg flex gap-2 hover:bg-blue-600" onClick={() => testControl(control.id)}>Test control</button>
            </ActionsLayoutHeader>
            <ActionsLayoutMain>
                <ActionsLayoutSection>
                    <div className="p-5">
                        <details open className="pb-5">
                            <summary className="text-2xl font-bold">General</summary>
                            <div className="grid gap-5">
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Control ID</span>
                                    <span>{control.id}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Control</span>
                                    <span>{control.name}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Description</span>
                                    <span className=" whitespace-pre-wrap">{control.description}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="font-bold">Owner</span>
                                    <span>{`User`}</span>
                                </div>
                            </div>
                        </details>

                        <details open className=" border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Control Tests</summary>
                            <div className="flex justify-around pt-4">
                                <div className="flex flex-col gap-1 justify-center items-center">
                                    <span className="font-bold">Design Effectiveness</span>
                                    {control.ControlAssertion.length > 0 && <div>{control.ControlAssertion[0]?.design ? 'Effective' : 'Not Effective'}</div>}
                                </div>
                                <div className="flex flex-col gap-1 justify-center items-center">
                                    <span className="font-bold">Adequacy</span>
                                    {control.ControlAssertion.length > 0 && <div>{control.ControlAssertion[0]?.adequacy ? 'Adequate' : 'Not Adequate'}</div>}
                                </div>
                            </div>

                        </details>

                        <details open className=" border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Control Issues</summary>
                            <div>
                                <h2 className="text-xl font-bold">Control Issues</h2>
                                <table className="bg-white w-full table-auto border mt-3">
                                    <thead>
                                        <tr>
                                            <th className="bg-[#dbdbdb]/30 border-x py-4">Issue name</th>
                                            <th className="bg-[#dbdbdb]/30 border-x py-4">Description</th>
                                            <th className="bg-[#dbdbdb]/30 border-x py-4">Priority</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr>
                                            <td className="text-center py-5 border-x" colSpan={3}>No Results</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </details>

                        <details open className="border-t-2 pb-5">
                            <summary className="text-2xl font-bold ">Mitigating Risks</summary>
                            <table className="bg-white w-full table-auto mt-3 border-y border-gray-200">
                                <thead>
                                    <tr>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Risk ID</th>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Risk name</th>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Impact</th>
                                        <th className="bg-[#dbdbdb]/30 border-x py-4">Likelihood</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        control.RiskControl.map(_rc => (
                                            <tr key={_rc.risk_id} className="hover:bg-indigo-50 cursor-pointer">
                                                <td className="text-center py-5 border-x">{_rc.risk_id}</td>
                                                <td className="text-center py-5 border-x">{_rc.risk.name}</td>
                                                <td className="text-center py-5 border-x">{_rc.risk.impact || 'N/A'}</td>
                                                <td className="text-center py-5 border-x">{_rc.risk.likelihood || 'N/A'}</td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                        </details>
                    </div>
                </ActionsLayoutSection>
                <ActionsLayoutSide>
                    <div className="card py-3 px-5 flex flex-col gap-2">
                        <div className="grid grid-cols-3">
                            <h3 className="font-semibold">
                                Stage
                            </h3>
                            <p className=" col-span-2">Assess Control</p>
                        </div>
                        <div className="grid grid-cols-3">
                            <h3 className="font-semibold">
                                Due Date
                            </h3>
                            <p className=" col-span-2">30/11/2022</p>
                        </div>
                    </div>
                    <div className="bg-white border-teal-600 border-2 py-3 px-5">
                        <h2 className="font-bold mb-2">Control Assessment</h2>
                        <p className="mb-1">Review and update the control information</p>
                        <p className="mb-1">Add, Review, Update test plans and provide Test Results.</p>
                    </div>
                </ActionsLayoutSide>
            </ActionsLayoutMain>
        </ActionsLayout>
    );
}



export default ControlPage
