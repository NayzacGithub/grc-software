import { NextApiRequest, NextApiResponse } from "next";
import { formidable } from 'formidable';

const ControlApiHandler = async (req: NextApiRequest, res: NextApiResponse) => {
    if (req.method === "POST") {
        const form = formidable({ multiples: true });
        form.parse(req, (err, fields, files) => {
            if (err) {
                res.status(500).json({ error: err.message });
            }
            res.writeHead(200, { 'content-type': 'application/json' });
            res.end(JSON.stringify({ fields, files }, null, 2));
        });
        res.status(500).json({ error: "Something went wrong" });

    } else {
        res.status(405).json({ message: "Method not allowed" });
    }
}

export default ControlApiHandler;