import formidable, { File } from "formidable";
import { IncomingMessage } from "http";
import { NextApiResponse } from "next";
import fs from 'fs'
import { uniqueId } from "lodash";
export const config = {
    api: {
        bodyParser: false,
    },
};

const handler = (req: IncomingMessage, res: NextApiResponse) => {
    const form = formidable({});
    form.parse(req, async function (err, fields, files) {
        // const settingsFile = fs.readFileSync('./public/settings.json');
        // const settings: Settings = JSON.parse(settingsFile.toString());
        if (files.file) {
            const file: File = files.file as File;
            const fileData = fs.readFileSync(file.filepath.toString());
            const uuid = uniqueId()
            fs.writeFileSync(`./public/images/${uuid}.${file?.originalFilename}`, fileData);
            await fs.unlinkSync(fileData);
        }
        if (err) {
            console.log(err);
        }
        // fs.writeFileSync('./public/system')

        return res.json({
            fields: fields,
            files: files,
        });
    });
}

export default handler;