import z from "zod";

export const controlGetAllFilterSchema = z.object({
    riskId: z.string().nullish()
});

export const createControlInputSchema = z.object({
    id: z.string(),
    name: z.string(),
    risk_id: z.string(),
    description: z.optional(z.string()),
    type: z.optional(z.enum(['PREVENTIVE', 'DETECTIVE', 'CORRECTIVE', 'DIRECTIVE'])),
    method: z.optional(z.enum(['MANUAL', 'AUTOMATED', 'PARTIALY_AUTOMATED'])),
    frequency: z.optional(z.enum(['DAILY', 'WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY', 'TRANSACTION_EVENT_DRIVEN'])),
    entityLevel: z.optional(z.enum(['ELC', 'PLC', 'TLC'])),
    controlClassification: z.optional(z.enum(['Key', 'Complimentary', 'Compensatory'])),
    antiFraud: z.optional(z.enum(['true', 'false'])),
    design: z.optional(z.enum(['EFFECTIVE', 'INEFFECTIVE'])),
    implementation: z.optional(z.enum(['EFFECTIVE', 'INEFFECTIVE'])),

});

export type CreateControlInput = z.TypeOf<typeof createControlInputSchema>;

export type ControlGetAllFilterSchema = z.TypeOf<typeof controlGetAllFilterSchema>;

