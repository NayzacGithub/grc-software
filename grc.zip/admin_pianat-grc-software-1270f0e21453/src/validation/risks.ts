import z from "zod";
export const createRiskInputSchema = z.object({
    id: z.string(),
    name: z.string(),
    description: z.optional(z.string()),
    event_type: z.optional(z.enum(['Opportunity_Risk', 'Risk_Of_Uncertainty', 'Risk_Of_Hazards', 'Operational_Risk'])),
    category: z.enum(['Strategic_Risk', 'Operational_Risk', 'Financial_Risk', 'Compliance_Risk', 'Reputational_Risk']),
    impact: z.string(),
    likelihood: z.string(),
    function_id: z.string(),
});

export const assessRiskSchema = z.object({
    risk_id: z.string(),
    likelihood: z.string(),
    impact: z.string(),
    assessing: z.enum(['residual', 'inherent'])
});

export type AssessRisk = z.TypeOf<typeof assessRiskSchema>;

export type CreateRiskInput = z.TypeOf<typeof createRiskInputSchema>;

export const riskGetAllFilterSchema = z.object({
    functionId: z.string().nullish()
});

export type RiskGetAllFilterSchema = z.TypeOf<typeof riskGetAllFilterSchema>;


export const riskAnalysisInputSchema = z.object({
    risk_id: z.string(),
    inherentImpact: z.string(),
    inherentLikelyhood: z.string(),
});

export type RiskAnalysisInput = z.TypeOf<typeof riskAnalysisInputSchema>;