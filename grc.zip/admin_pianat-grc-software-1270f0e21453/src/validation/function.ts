import z from 'zod';

export const createFunctionInputSchema = z.object({
    id: z.string(),
    name: z.string(),
    description: z.optional(z.string())
});

export type CreateFunctionInput = z.TypeOf<typeof createFunctionInputSchema>;