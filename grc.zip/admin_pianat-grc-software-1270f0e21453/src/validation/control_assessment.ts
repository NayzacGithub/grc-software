import z from 'zod';

export const createControlAssessmentInputSchema = z.object({
    control_id: z.string(),
    adequacy: z.string(),
    design: z.string(),
    signiture: z.string(),
    impact: z.string(),
    recommendation: z.string(),
});

export type CreateControlAssessmentInput = z.infer<typeof createControlAssessmentInputSchema>;
